// Copyright (c) 2016 The Decred developers
// Copyright (c) 2018-2020 The Hc developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

// Package ticketbuyer provides an implementation of automatic ticket
// purchasing for a hcd wallet.
package ticketbuyer
