// Package zero contains functions to clear data from byte slices and
// multi-precision integers.
package zero
