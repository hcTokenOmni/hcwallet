pgpwordlist
===========

This package provides the pgpwordlist for use when generating a human
readable hash or seed as well as functions for working with it.

## Installation and updating
```bash
$ go get -u github.com/HcashOrg/hcwallet/
```
