
int DllCallBack(int nType);
char* DllCallBackChar(int nType, char* str);
char* DllCallBackCharEx(int nType, char* str, int len);


int CallCpp(int type, void* param);