
int GoCallback(int ntype);
char* GoCallbackChar(int ntype, char* context);
char* GoCallbackCharEx(int ntype, char* context, int len);
