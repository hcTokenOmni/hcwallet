### Guides

[Spending funds offline using cold wallets](https://github.com/HcashOrg/hcwallet/tree/master/docs/offline_wallets.md)
